package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class StuckEntityCleaner {
    private final EcoChillLagFixer plugin;

    public StuckEntityCleaner(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void startScheduler() {
        if (!plugin.getConfig().getBoolean("stuck-entity.enabled")) return;
        long interval = plugin.getConfig().getLong("stuck-entity.check-interval-seconds", 60) * 20L;
        
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::cleanStuckEntities, interval, interval);
    }

    private void cleanStuckEntities() {
        for (World world : Bukkit.getWorlds()) {
            for (LivingEntity entity : world.getLivingEntities()) {
                if (entity instanceof Player) continue;
                if (entity.getCustomName() != null) continue;

                Location loc = entity.getLocation();
                // Simple logic: if inside a solid block
                if (loc.getBlock().getType().isSolid() && loc.add(0, 1, 0).getBlock().getType().isSolid()) {
                     entity.remove(); // Remove suffocating/stuck mobs
                }
            }
        }
    }
}
