package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Chunk;
import org.bukkit.entity.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class EntityLimiterManager {
    private final EcoChillLagFixer plugin;

    public EntityLimiterManager(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public boolean isLimitReached(Chunk chunk, EntityType type) {
        if (!plugin.getConfig().getBoolean("entity-limiter.enabled")) return false;
        
        int max = plugin.getConfig().getInt("entity-limiter.max-per-chunk", 30);
        if (type == EntityType.VILLAGER) {
            max = plugin.getConfig().getInt("entity-limiter.villager-max-per-chunk", 10);
        }
        return chunk.getEntities().length >= max;
    }

    public void cleanChunk(Chunk chunk) {
        Entity[] entities = chunk.getEntities();
        int max = plugin.getConfig().getInt("entity-limiter.max-per-chunk", 30);
        
        if (entities.length <= max) return;

        // Ưu tiên giữ: Player, Named, Pet, Persistent
        List<Entity> removable = Arrays.stream(entities)
                .filter(e -> !(e instanceof Player))
                .filter(e -> e.getCustomName() == null)
                .filter(e -> !(e instanceof Tameable && ((Tameable) e).isTamed()))
                .filter(e -> !e.getPersistentDataContainer().isEmpty())
                .sorted(Comparator.comparingInt(this::getEntityPriority))
                .collect(Collectors.toList());

        int toRemove = entities.length - max;
        for (int i = 0; i < toRemove && i < removable.size(); i++) {
            removable.get(i).remove();
        }
    }

    private int getEntityPriority(Entity e) {
        if (e instanceof Monster) return 0; // Xóa trước
        if (e instanceof Animals) return 1;
        if (e instanceof Item) return 2;
        return 10; // Giữ lại
    }
}
