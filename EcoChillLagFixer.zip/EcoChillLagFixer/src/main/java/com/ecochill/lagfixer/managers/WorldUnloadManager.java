package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import java.util.List;

public class WorldUnloadManager {
    private final EcoChillLagFixer plugin;
    public WorldUnloadManager(EcoChillLagFixer plugin) { this.plugin = plugin; }

    public void checkWorlds() {
        if (!plugin.getConfig().getBoolean("world-unload.enabled")) return;
        List<String> whitelist = plugin.getConfig().getStringList("world-unload.whitelisted-worlds");

        for (World world : Bukkit.getWorlds()) {
            if (whitelist.contains(world.getName())) continue;
            if (world.getPlayers().isEmpty()) {
                plugin.getLogger().info("Unloading empty world: " + world.getName());
                Bukkit.unloadWorld(world, true);
            }
        }
    }
}
