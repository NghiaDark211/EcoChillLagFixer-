package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Chunk;
import org.bukkit.block.Block;

import java.util.HashMap;
import java.util.Map;

public class RedstoneMonitor {
    private final EcoChillLagFixer plugin;
    private final Map<Long, Integer> chunkRedstoneCounts = new HashMap<>();
    private long lastReset = System.currentTimeMillis();

    public RedstoneMonitor(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void onRedstoneEvent(Block block) {
        if (!plugin.getConfig().getBoolean("redstone-monitor.enabled")) return;

        if (System.currentTimeMillis() - lastReset > 1000) {
            chunkRedstoneCounts.clear();
            lastReset = System.currentTimeMillis();
        }

        long key = Chunk.getChunkKey(block.getX() >> 4, block.getZ() >> 4);
        int count = chunkRedstoneCounts.getOrDefault(key, 0) + 1;
        chunkRedstoneCounts.put(key, count);

        int max = plugin.getConfig().getInt("redstone-monitor.max-updates-per-second", 200);
        if (count > max && count % 50 == 0) {
            String action = plugin.getConfig().getString("redstone-monitor.action", "LOG");
            if ("BREAK".equalsIgnoreCase(action)) {
                block.breakNaturally();
                plugin.getLogger().warning("Đã phá mạch redstone tại: " + block.getLocation());
            } else {
                plugin.getLogger().info("Redstone cao (" + count + ") tại: " + block.getLocation());
            }
        }
    }
}
