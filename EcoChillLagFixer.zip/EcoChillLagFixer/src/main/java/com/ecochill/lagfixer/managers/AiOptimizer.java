package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;

public class AiOptimizer {
    private final EcoChillLagFixer plugin;
    private boolean lowTpsMode = false;

    public AiOptimizer(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void checkTPS() {
        if (!plugin.getConfig().getBoolean("ai-optimizer.enabled")) return;
        double tps = Bukkit.getTPS()[0];
        double threshold = plugin.getConfig().getDouble("ai-optimizer.tps-threshold", 18.0);

        if (tps < threshold && !lowTpsMode) {
            lowTpsMode = true;
            plugin.getLogger().warning("TPS Thấp (" + String.format("%.2f", tps) + "). Bật chế độ tối ưu hóa.");
        } else if (tps > threshold + 1.0 && lowTpsMode) {
            lowTpsMode = false;
            plugin.getLogger().info("TPS Ổn định. Tắt chế độ tối ưu hóa.");
        }
    }
}
