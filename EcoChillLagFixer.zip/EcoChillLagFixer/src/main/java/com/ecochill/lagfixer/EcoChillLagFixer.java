package com.ecochill.lagfixer;

import com.ecochill.lagfixer.commands.LagFixerCommand;
import com.ecochill.lagfixer.listeners.EventListener;
import com.ecochill.lagfixer.managers.*;
import org.bukkit.plugin.java.JavaPlugin;

public class EcoChillLagFixer extends JavaPlugin {

    private static EcoChillLagFixer instance;
    
    // Feature Managers
    public EntityLimiterManager entityLimiter;
    public ClearLagManager clearLagManager;
    public ChunkFreezerManager chunkFreezer;
    public RedstoneMonitor redstoneMonitor;
    public HopperOptimizer hopperOptimizer;
    public PerformanceMonitor performanceMonitor;
    public FarmLimiter farmLimiter;
    public WorldUnloadManager worldUnloadManager;
    public StuckEntityCleaner stuckEntityCleaner;
    public AiOptimizer aiOptimizer;
    public ItemStackingManager itemStackingManager; // New feature

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // 1. Initialize Managers
        this.entityLimiter = new EntityLimiterManager(this);
        this.clearLagManager = new ClearLagManager(this);
        this.chunkFreezer = new ChunkFreezerManager(this);
        this.redstoneMonitor = new RedstoneMonitor(this);
        this.hopperOptimizer = new HopperOptimizer(this);
        this.performanceMonitor = new PerformanceMonitor(this);
        this.farmLimiter = new FarmLimiter(this);
        this.worldUnloadManager = new WorldUnloadManager(this);
        this.stuckEntityCleaner = new StuckEntityCleaner(this);
        this.aiOptimizer = new AiOptimizer(this);
        this.itemStackingManager = new ItemStackingManager(this); // Init new feature

        // 2. Register Commands & Listeners
        getCommand("lagfixer").setExecutor(new LagFixerCommand(this));
        getServer().getPluginManager().registerEvents(new EventListener(this), this);

        // 3. Start Tasks
        startSchedulers();
        
        getLogger().info("EcoChillLagFixer (1.21) enabled successfully!");
    }

    private void startSchedulers() {
        long interval = getConfig().getLong("settings.check-interval-ticks", 100L);
        
        // Main Loop (Async/Sync hybrid tasks handled by managers)
        getServer().getScheduler().runTaskTimer(this, () -> {
            aiOptimizer.checkTPS();
            performanceMonitor.collectMetrics();
            worldUnloadManager.checkWorlds();
            chunkFreezer.checkChunks(); // Check for idle chunks
        }, 100L, interval);
        
        // Feature specific loops
        clearLagManager.startScheduler();
        stuckEntityCleaner.startScheduler();
        performanceMonitor.startLogTask();
        itemStackingManager.startStackingTask(); // Start stacking task
    }

    @Override
    public void onDisable() {
        if (performanceMonitor != null) performanceMonitor.saveMetricsImmediately();
        getLogger().info("EcoChillLagFixer disabled.");
    }

    public static EcoChillLagFixer getInstance() {
        return instance;
    }
}
