package com.ecochill.lagfixer.commands;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

public class LagFixerCommand implements CommandExecutor {
    private final EcoChillLagFixer plugin;
    public LagFixerCommand(EcoChillLagFixer plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0) {
            sender.sendMessage(ChatColor.GREEN + "EcoChillLagFixer 1.21 v1.0.0");
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            plugin.reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "Config reloaded!");
        } else if (args[0].equalsIgnoreCase("clearitems")) {
            plugin.clearLagManager.clearItems(false);
            sender.sendMessage(ChatColor.YELLOW + "Cleared items.");
        } else if (args[0].equalsIgnoreCase("status")) {
            sender.sendMessage(ChatColor.AQUA + "TPS: " + String.format("%.2f", plugin.performanceMonitor.getTPS()));
        }
        return true;
    }
}
