package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Location;
import org.bukkit.block.Hopper;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryMoveItemEvent;

public class HopperOptimizer {
    private final EcoChillLagFixer plugin;

    public HopperOptimizer(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void handleHopperMove(InventoryMoveItemEvent event) {
        if (!plugin.getConfig().getBoolean("hopper-optimizer.enabled")) return;

        if (event.getInitiator().getHolder() instanceof Hopper hopper) {
            Location loc = hopper.getLocation();
            int radius = plugin.getConfig().getInt("hopper-optimizer.check-radius", 3);
            
            if (loc.getWorld().getPlayers().isEmpty()) {
                event.setCancelled(true);
                return;
            }

            boolean playerNear = false;
            for (Player p : loc.getWorld().getPlayers()) {
                if (p.getLocation().distanceSquared(loc) < (radius * radius)) {
                    playerNear = true;
                    break;
                }
            }

            if (!playerNear) {
                event.setCancelled(true); // Disable if no player
            } else {
                int cooldown = plugin.getConfig().getInt("hopper-optimizer.transfer-interval", 8);
                hopper.setTransferCooldown(cooldown);
            }
        }
    }
}
