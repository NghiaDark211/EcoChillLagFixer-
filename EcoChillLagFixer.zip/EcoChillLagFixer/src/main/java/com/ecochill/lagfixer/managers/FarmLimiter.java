package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;

import java.util.Collection;

public class FarmLimiter {
    private final EcoChillLagFixer plugin;

    public FarmLimiter(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public boolean canSpawn(Location loc, EntityType type) {
        if (!plugin.getConfig().getBoolean("farm-limiter.enabled")) return true;
        
        int radius = plugin.getConfig().getInt("farm-limiter.check-radius", 10);
        int limit = plugin.getConfig().getInt("farm-limiter.max-mobs-in-radius", 20);

        Collection<Entity> nearby = loc.getWorld().getNearbyEntities(loc, radius, radius, radius);
        long count = nearby.stream().filter(e -> e.getType() == type).count();

        return count < limit;
    }
}
