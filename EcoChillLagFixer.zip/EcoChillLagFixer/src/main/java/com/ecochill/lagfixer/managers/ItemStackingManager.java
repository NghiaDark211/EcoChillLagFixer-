package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays; // <--- Đã thêm
import java.util.Comparator; // <--- Đã thêm (Fix lỗi 2)
import java.util.List;
import java.util.stream.Collectors;

/**
 * Quản lý tính năng gom item rơi (Item Stacking) để giảm lag.
 */
public class ItemStackingManager {
    private final EcoChillLagFixer plugin;
    private final double stackRadiusSq;
    private final int maxStack;
    private final List<String> blacklist;

    public ItemStackingManager(EcoChillLagFixer plugin) {
        this.plugin = plugin;
        this.stackRadiusSq = Math.pow(plugin.getConfig().getDouble("item-stacking.stack-radius", 2.5), 2);
        this.maxStack = plugin.getConfig().getInt("item-stacking.max-stack-amount", 512);
        this.blacklist = plugin.getConfig().getStringList("item-stacking.item-blacklist");
    }
    
    /**
     * Khởi động task định kỳ để gom các item cũ.
     */
    public void startStackingTask() {
        if (!plugin.getConfig().getBoolean("item-stacking.enabled")) return;
        
        long interval = plugin.getConfig().getLong("item-stacking.stack-interval-ticks", 40);
        
        // Chạy bất đồng bộ để tránh ảnh hưởng tick rate
        Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, this::scanAndStackAllWorlds, 100L, interval);
    }

    private void scanAndStackAllWorlds() {
        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                // FIX LỖI 1: Dùng Arrays.stream() thay vì gọi .stream() trực tiếp từ mảng
                List<Item> items = Arrays.stream(chunk.getEntities()) 
                        .filter(e -> e instanceof Item)
                        .map(e -> (Item) e)
                        .collect(Collectors.toList());
                
                if (items.size() > 1) {
                    processChunkItems(items);
                }
            }
        }
    }

    /**
     * Xử lý gom item khi có item mới rơi xuống.
     */
    public void onItemSpawn(ItemSpawnEvent event) {
        if (!plugin.getConfig().getBoolean("item-stacking.enabled")) return;
        
        Item newItem = event.getEntity();
        if (!canBeStacked(newItem)) return;

        // Tìm item gần nhất để gom
        mergeNearbyItem(newItem);
    }

    /**
     * Xử lý item khi player nhặt.
     */
    public void onItemPickup(EntityPickupItemEvent event) {
        Item item = event.getItem();
        ItemStack stack = item.getItemStack();
        
        // Logic placeholder để tránh lỗi logic khi nhặt stack lớn
        if (stack.getAmount() > stack.getMaxStackSize() && item.getCustomName() == null) {
            // Paper server tự xử lý khá tốt việc này, ta để mặc định
        }
    }

    /**
     * Lọc và gom các item trong danh sách (thường là trong một chunk).
     * @param items Danh sách Item Entity
     */
    private void processChunkItems(List<Item> items) {
        if (items.isEmpty()) return;
        
        // FIX LỖI 2: Đã có import java.util.Comparator
        items.sort(Comparator.comparing(Entity::getUniqueId));

        for (int i = 0; i < items.size(); i++) {
            Item target = items.get(i);
            if (target.isDead() || !canBeStacked(target)) continue;

            for (int j = i + 1; j < items.size(); j++) {
                Item source = items.get(j);
                if (source.isDead() || !canBeStacked(source)) continue;

                if (canStack(target, source) && target.getLocation().distanceSquared(source.getLocation()) <= stackRadiusSq) {
                    mergeItems(target, source);
                    // Sau khi merge, item 'source' đã bị remove, nên ta continue vòng lặp j
                }
            }
        }
    }

    /**
     * Cố gắng gom item mới (newItem) vào một item đã tồn tại gần đó.
     * @param newItem Item Entity mới.
     */
    private void mergeNearbyItem(Item newItem) {
        // Tìm các entity trong bán kính stackRadiusSq
        for (Entity nearby : newItem.getNearbyEntities(Math.sqrt(stackRadiusSq), Math.sqrt(stackRadiusSq), Math.sqrt(stackRadiusSq))) {
            if (nearby instanceof Item existingItem && !existingItem.equals(newItem)) {
                if (canStack(existingItem, newItem)) {
                    // Nếu gom thành công, hủy sự kiện spawn của item mới bằng cách merge và xóa nó
                    mergeItems(existingItem, newItem);
                    newItem.remove();
                    return;
                }
            }
        }
    }

    /**
     * Kiểm tra hai Item Entity có thể gom lại với nhau không.
     */
    private boolean canStack(Item item1, Item item2) {
        if (item1.isDead() || item2.isDead() || item1.getCustomName() != null || item2.getCustomName() != null) {
            return false;
        }

        ItemStack stack1 = item1.getItemStack();
        ItemStack stack2 = item2.getItemStack();

        // 1. Kiểm tra loại vật phẩm
        if (stack1.getType() != stack2.getType()) {
            return false;
        }
        
        // 2. Kiểm tra Blacklist
        if (blacklist.contains(stack1.getType().name())) {
            return false;
        }

        // 3. Kiểm tra Metadata/NBT
        ItemMeta meta1 = stack1.getItemMeta();
        ItemMeta meta2 = stack2.getItemMeta();
        
        if (meta1 == null && meta2 == null) return true;
        if (meta1 == null || meta2 == null) return false;
        
        return meta1.equals(meta2);
    }
    
    private boolean canBeStacked(Item item) {
        if (item.getCustomName() != null) return false;
        return !blacklist.contains(item.getItemStack().getType().name());
    }

    private void mergeItems(Item target, Item source) {
        ItemStack targetStack = target.getItemStack();
        ItemStack sourceStack = source.getItemStack();
        
        int totalAmount = targetStack.getAmount() + sourceStack.getAmount();
        
        if (totalAmount <= maxStack) {
            targetStack.setAmount(totalAmount);
            target.setItemStack(targetStack);
            source.remove();
        } else {
            // Nếu vượt quá giới hạn
            int transferAmount = maxStack - targetStack.getAmount(); 
            if (transferAmount > 0) {
                targetStack.setAmount(maxStack);
                target.setItemStack(targetStack);
                
                sourceStack.setAmount(totalAmount - maxStack);
                source.setItemStack(sourceStack);
            }
        }
    }
}
