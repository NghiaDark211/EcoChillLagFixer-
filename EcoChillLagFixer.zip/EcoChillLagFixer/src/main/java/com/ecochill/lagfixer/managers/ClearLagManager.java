package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;

import java.util.List;

public class ClearLagManager {
    private final EcoChillLagFixer plugin;

    public ClearLagManager(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void startScheduler() {
        if (!plugin.getConfig().getBoolean("clear-lag.enabled")) return;
        long interval = plugin.getConfig().getLong("clear-lag.interval-seconds", 300) * 20L;
        
        plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            Bukkit.broadcastMessage(plugin.getConfig().getString("clear-lag.warning-msg").replace("&", "§"));
            // Delay clear 5 seconds after warning if needed, here we clear immediately for simplicity
            clearItems(false);
        }, interval, interval);
    }

    public int clearItems(boolean dryRun) {
        int count = 0;
        List<String> blacklist = plugin.getConfig().getStringList("clear-lag.blacklist");

        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (entity instanceof Item item) {
                    if (item.getTicksLived() < 100) continue; 
                    if (item.getCustomName() != null) continue;
                    
                    String typeName = item.getItemStack().getType().name();
                    // Kiểm tra item 1.21 hoặc item quý
                    if (blacklist.contains(typeName)) continue;

                    if (!dryRun) item.remove();
                    count++;
                }
            }
        }
        if (!dryRun) plugin.getLogger().info("Đã dọn dẹp " + count + " items.");
        return count;
    }
}
