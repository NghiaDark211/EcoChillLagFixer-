package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class PerformanceMonitor {
    private final EcoChillLagFixer plugin;

    public PerformanceMonitor(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public double getTPS() {
        return Bukkit.getTPS()[0]; // 1m average
    }

    public void collectMetrics() { /* Runtime stats hook */ }

    public void startLogTask() {
        if (!plugin.getConfig().getBoolean("performance-monitor.export-csv")) return;
        long interval = plugin.getConfig().getLong("performance-monitor.export-interval-minutes", 5) * 1200L;
        plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, this::saveMetricsImmediately, interval, interval);
    }

    public void saveMetricsImmediately() {
        File file = new File(plugin.getDataFolder(), "metrics.log");
        try (PrintWriter writer = new PrintWriter(new FileWriter(file, true))) {
            double tps = getTPS();
            int entities = 0;
            for(World w : Bukkit.getWorlds()) entities += w.getEntityCount();
            
            writer.printf("[%s] TPS: %.2f | Entities: %d%n", LocalDateTime.now(), tps, entities);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
