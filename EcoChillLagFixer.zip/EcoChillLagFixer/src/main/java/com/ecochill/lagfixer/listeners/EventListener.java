package com.ecochill.lagfixer.listeners;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.world.ChunkLoadEvent;

public class EventListener implements Listener {
    private final EcoChillLagFixer plugin;

    public EventListener(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    // --- Entity Spawning & Limits ---
    @EventHandler
    public void onSpawn(EntitySpawnEvent event) {
        // Feature 1: Smart Entity Limiter
        if (plugin.entityLimiter.isLimitReached(event.getEntity().getLocation().getChunk(), event.getEntity().getType())) {
            event.setCancelled(true);
            return;
        }
        // Feature 7: Farm Limiter
        if (!plugin.farmLimiter.canSpawn(event.getLocation(), event.getEntityType())) {
            event.setCancelled(true);
        }
    }

    // --- Chunk Management ---
    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        // Feature 1: Clean excessive entities on load
        plugin.entityLimiter.cleanChunk(event.getChunk());
    }

    // --- Redstone Optimization ---
    @EventHandler
    public void onRedstone(BlockRedstoneEvent event) {
        // Feature 4: Anti Redstone Lag
        plugin.redstoneMonitor.onRedstoneEvent(event.getBlock());
    }

    // --- Hopper Optimization ---
    @EventHandler
    public void onHopper(InventoryMoveItemEvent event) {
        // Feature 5: Hopper Optimizer
        plugin.hopperOptimizer.handleHopperMove(event);
    }

    // --- Item Stacking (New Feature) ---
    @EventHandler
    public void onItemSpawn(ItemSpawnEvent event) {
        // Feature 11: Auto merge newly spawned items
        plugin.itemStackingManager.onItemSpawn(event);
    }

    @EventHandler
    public void onEntityPickupItem(EntityPickupItemEvent event) {
        // Feature 11: Handle stacking logic during pickup (optional safeguards)
        plugin.itemStackingManager.onItemPickup(event);
    }
}
