package com.ecochill.lagfixer.managers;

import com.ecochill.lagfixer.EcoChillLagFixer;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

public class ChunkFreezerManager {
    private final EcoChillLagFixer plugin;

    public ChunkFreezerManager(EcoChillLagFixer plugin) {
        this.plugin = plugin;
    }

    public void checkChunks() {
        if (!plugin.getConfig().getBoolean("chunk-freezer.enabled")) return;

        for (World world : Bukkit.getWorlds()) {
            for (Chunk chunk : world.getLoadedChunks()) {
                boolean hasPlayer = false;
                for (Entity e : chunk.getEntities()) {
                    if (e instanceof Player) {
                        hasPlayer = true;
                        break;
                    }
                }
                
                // Toggle AI based on player presence
                toggleChunkAI(chunk, hasPlayer);
            }
        }
    }

    private void toggleChunkAI(Chunk chunk, boolean enable) {
        for (Entity e : chunk.getEntities()) {
            if (e instanceof LivingEntity && !(e instanceof Player)) {
                ((LivingEntity) e).setAI(enable);
            }
        }
    }
}
